{{/*
Expand the name of the chart.
*/}}
{{- define "kubementor-api.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "kubementor-api.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kubementor-api.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kubementor-api.labels" -}}
helm.sh/chart: {{ include "kubementor-api.chart" . }}
{{ include "kubementor-api.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kubementor-api.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubementor-api.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "kubementor-api.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kubementor-api.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Database URL - from secret or direct value
*/}}
{{- define "kubementor-api.databaseSecretName" -}}
{{- if .Values.config.database.existingSecret }}
{{- .Values.config.database.existingSecret }}
{{- else }}
{{- include "kubementor-api.fullname" . }}-db
{{- end }}
{{- end }}

{{/*
Claude API Key secret name
*/}}
{{- define "kubementor-api.claudeSecretName" -}}
{{- if .Values.config.claude.existingSecret }}
{{- .Values.config.claude.existingSecret }}
{{- else }}
{{- include "kubementor-api.fullname" . }}-claude
{{- end }}
{{- end }}
